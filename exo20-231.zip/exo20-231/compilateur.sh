cat commande.mes | ./exo20-23
make
